function masterjournal() {
    
  return (
    <div>
      <h1>Master Journal</h1>
    </div>
  );
}

export default masterjournal;